// 通信行业客户资料库 - 后端服务
// 环境变量：
//   PORT            本地开发端口（默认 5001）
//   SOCKET_PATH     安装到飞牛 fnOS 后监听的 Unix Socket（统一网关转发）
//   GATEWAY_PREFIX  统一网关访问前缀（默认 /app/custdb）
//   DATA_DIR        数据保存目录（fnOS 上指向 data-share 创建的数据目录）
// 统一网关转发时携带 X-Trim-Userid，用于区分不同 NAS 用户的数据。
"use strict";

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const XLSX = require("xlsx");

const PORT_DEFAULT = 5001;
const SOCKET_PATH = process.env.SOCKET_PATH || "";
const GATEWAY_PREFIX = (process.env.GATEWAY_PREFIX || "/app/custdb").replace(/\/+$/, "");
const PUBLIC_DIR = path.join(__dirname, "public");
const DEFAULT_DATA_DIR = path.join(__dirname, "data");

const app = express();
app.use(express.json({ limit: "1mb" }));

// 文件上传（内存存储，供数据导入使用）
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }
});

// ---------------- 数据存储（SQLite + 数据路径自定义） ----------------
// config.json 位于“基础数据目录”（env DATA_DIR 或默认 data/），字段：
//   dataDir —— 数据存放路径（自定义，绝对路径；默认与基础数据目录一致）
//   port    —— 额外监听的 TCP 服务端口（局域网直连 / 隧道映射用；默认 5001）
// 存储方式固定为 SQLite（Node 内置 node:sqlite，零外部依赖，适合大数据量）。
// 数据路径优先级：config.json dataDir（用户自定义）> env DATA_DIR（部署默认）> 默认 data/
function loadAppConfig() {
  const baseDir = process.env.DATA_DIR || DEFAULT_DATA_DIR;
  let cfg = {};
  try {
    const f = path.join(baseDir, "config.json");
    if (fs.existsSync(f)) cfg = JSON.parse(fs.readFileSync(f, "utf8")) || {};
  } catch (e) { /* 配置损坏时使用默认值 */ }
  if (typeof cfg !== "object" || cfg === null || Array.isArray(cfg)) cfg = {};

  let dataDir = process.env.DATA_DIR || DEFAULT_DATA_DIR;
  let dataDirSource = "env";
  if (cfg.dataDir && typeof cfg.dataDir === "string" && cfg.dataDir.trim()) {
    dataDir = cfg.dataDir.trim();
    dataDirSource = "config";
  }

  const appPort = Number(cfg.port);
  return {
    storage: "sqlite",
    dataDir,
    dataDirSource,
    appPort: Number.isInteger(appPort) && appPort >= 1 && appPort <= 65535 ? appPort : null,
    requireLogin: cfg.requireLogin !== false, // 默认开启：所有用户都需要登录验证
    cfgFile: path.join(baseDir, "config.json")
  };
}

function readAppConfig() {
  const f = path.join(process.env.DATA_DIR || DEFAULT_DATA_DIR, "config.json");
  try {
    if (fs.existsSync(f)) {
      const c = JSON.parse(fs.readFileSync(f, "utf8"));
      if (typeof c === "object" && c !== null && !Array.isArray(c)) return c;
    }
  } catch (e) { /* ignore */ }
  return {};
}

function writeAppConfig(cfg) {
  const f = path.join(process.env.DATA_DIR || DEFAULT_DATA_DIR, "config.json");
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, JSON.stringify(cfg, null, 2));
}

const APP_CFG = loadAppConfig();
const DATA_DIR = APP_CFG.dataDir;
// TCP 服务端口：优先级 env PORT（启动脚本传入）> config.json port（向导/设置页）> 默认 5001
const PORT = Number(process.env.PORT || APP_CFG.appPort || PORT_DEFAULT);
fs.mkdirSync(DATA_DIR, { recursive: true });

function userOf(req) {
  const uid = String(req.headers["x-trim-userid"] || "local").replace(/[^\w.-]/g, "");
  return uid || "local";
}

// SQLite 后端（Node 22 内置 node:sqlite，无需安装额外依赖）
let sqliteDb = null;
function sqliteGet() {
  if (!sqliteDb) {
    const { DatabaseSync } = require("node:sqlite");
    sqliteDb = new DatabaseSync(path.join(DATA_DIR, "custdb.db"));
    sqliteDb.exec(
      "CREATE TABLE IF NOT EXISTS customers (" +
      "id TEXT PRIMARY KEY, user TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, " +
      "idAddress TEXT, installAddress TEXT, planName TEXT, planFee REAL, addonServices TEXT, " +
      "operator TEXT, remark TEXT, contractStart TEXT, contractEnd TEXT, createdAt TEXT)"
    );
    // 兼容旧库：为已存在的 customers 表补充新增列（operator 运营商 / remark 备注）
    try { sqliteDb.exec("ALTER TABLE customers ADD COLUMN operator TEXT"); } catch (e) { /* 列已存在则忽略 */ }
    try { sqliteDb.exec("ALTER TABLE customers ADD COLUMN remark TEXT"); } catch (e) { /* 列已存在则忽略 */ }
    sqliteDb.exec(
      "CREATE TABLE IF NOT EXISTS portin (" +
      "id TEXT PRIMARY KEY, user TEXT NOT NULL, phone TEXT NOT NULL, " +
      "familyAddress TEXT, planName TEXT, planFee REAL, decider TEXT, " +
      "operator TEXT, remark TEXT, createdAt TEXT)"
    );
    // 兼容旧库：为已存在的 portin 表补充新增列（operator 运营商 / remark 备注）
    try { sqliteDb.exec("ALTER TABLE portin ADD COLUMN operator TEXT"); } catch (e) { /* 列已存在则忽略 */ }
    try { sqliteDb.exec("ALTER TABLE portin ADD COLUMN remark TEXT"); } catch (e) { /* 列已存在则忽略 */ }
    sqliteDb.exec("CREATE INDEX IF NOT EXISTS idx_customers_user ON customers(user)");
    sqliteDb.exec("CREATE INDEX IF NOT EXISTS idx_portin_user ON portin(user)");
  }
  return sqliteDb;
}

function rowToObj(r) {
  return {
    id: r.id, name: r.name, phone: r.phone,
    idAddress: r.idAddress || "", installAddress: r.installAddress || "",
    planName: r.planName || "", planFee: r.planFee == null ? null : r.planFee,
    addonServices: r.addonServices || "", operator: r.operator || "", remark: r.remark || "",
    contractStart: r.contractStart || "",
    contractEnd: r.contractEnd || "", createdAt: r.createdAt || ""
  };
}

function portinRowToObj(r) {
  return {
    id: r.id, phone: r.phone,
    familyAddress: r.familyAddress || "", planName: r.planName || "",
    planFee: r.planFee == null ? null : r.planFee,
    decider: r.decider || "", operator: r.operator || "", remark: r.remark || "",
    createdAt: r.createdAt || ""
  };
}

function readCustomersByUid(user) {
  return sqliteGet().prepare("SELECT * FROM customers WHERE user=? ORDER BY createdAt").all(user).map(rowToObj);
}

function writeCustomersByUid(user, list) {
  const db = sqliteGet();
  db.exec("BEGIN");
  try {
    db.prepare("DELETE FROM customers WHERE user=?").run(user);
    const ins = db.prepare(
      "INSERT OR REPLACE INTO customers (id,user,name,phone,idAddress,installAddress,planName,planFee,addonServices,operator,remark,contractStart,contractEnd,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    for (const c of list) {
      ins.run(c.id, user, c.name, c.phone, c.idAddress || "", c.installAddress || "", c.planName || "",
        c.planFee == null ? null : c.planFee, c.addonServices || "", c.operator || "", c.remark || "", c.contractStart || "",
        c.contractEnd || "", c.createdAt || "");
    }
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

function readCustomers(req) {
  return readCustomersByUid(req.auth ? req.auth.uid : userOf(req));
}

function writeCustomers(req, list) {
  writeCustomersByUid(req.auth ? req.auth.uid : userOf(req), list);
}

// ---------------- 异网用户（策反名单） ----------------
function readPortinByUid(user) {
  return sqliteGet().prepare("SELECT * FROM portin WHERE user=? ORDER BY createdAt").all(user).map(portinRowToObj);
}

function writePortinByUid(user, list) {
  const db = sqliteGet();
  db.exec("BEGIN");
  try {
    db.prepare("DELETE FROM portin WHERE user=?").run(user);
    const ins = db.prepare(
      "INSERT OR REPLACE INTO portin (id,user,phone,familyAddress,planName,planFee,decider,operator,remark,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?)"
    );
    for (const c of list) {
      ins.run(c.id, user, c.phone, c.familyAddress || "", c.planName || "",
        c.planFee == null ? null : c.planFee, c.decider || "", c.operator || "", c.remark || "", c.createdAt || "");
    }
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

function readPortin(req) {
  return readPortinByUid(req.auth ? req.auth.uid : userOf(req));
}

function writePortin(req, list) {
  writePortinByUid(req.auth ? req.auth.uid : userOf(req), list);
}

function storageInfo() {
  return {
    storage: "sqlite",
    dataDir: DATA_DIR,
    dataDirSource: APP_CFG.dataDirSource,
    configFile: APP_CFG.cfgFile,
    dbFile: path.join(DATA_DIR, "custdb.db"),
    appPort: PORT,
    appPortSource: process.env.PORT ? "env" : (APP_CFG.appPort ? "config" : "default"),
    requireLogin: APP_CFG.requireLogin,
    appFileDir: process.env.TRIM_DATA_SHARE_PATHS ? String(process.env.TRIM_DATA_SHARE_PATHS).split(":")[0] : null,
    pkgVarDir: process.env.TRIM_PKGVAR || null
  };
}

// 首次使用写入示例数据（虚构演示数据，可在页面中删除）
const SEED = [
  { id: "KH-2026-001", name: "王秀英", phone: "13800001234", idAddress: "四川省泸州市合江县XX镇XX村X社", installAddress: "四川省泸州市合江县XX街道XX小区X栋X单元", planName: "家庭融合宽带套餐", planFee: 129, addonServices: "视频彩铃、家庭云盘", operator: "中国移动", remark: "老客户，宽带2026-09已到期，待续费回访", contractStart: "2024-10-01", contractEnd: "2026-09-15", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-002", name: "李建国", phone: "13900005678", idAddress: "四川省泸州市合江县XX街道XX路X号", installAddress: "四川省泸州市合江县XX镇XX街XX号", planName: "5G畅享套餐", planFee: 99, addonServices: "腾讯视频会员", operator: "中国移动", remark: "协议10月到期，主推5G融合套餐", contractStart: "2024-10-10", contractEnd: "2026-10-10", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-003", name: "张桂芳", phone: "13600009876", idAddress: "四川省泸州市合江县XX乡XX村X组", installAddress: "四川省泸州市合江县XX小区X栋X单元", planName: "5G融合家庭套餐", planFee: 159, addonServices: "宽带提速包、视频彩铃", operator: "中国联通", remark: "", contractStart: "2024-11-01", contractEnd: "2026-11-01", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-004", name: "刘德明", phone: "13700004567", idAddress: "四川省泸州市合江县XX镇XX村X社", installAddress: "四川省泸州市合江县XX路XX号", planName: "手机流量畅享套餐", planFee: 59, addonServices: "亲情网、骚扰拦截", operator: "中国联通", remark: "有意向办理家庭宽带", contractStart: "2025-01-15", contractEnd: "2027-01-15", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-005", name: "陈秀兰", phone: "15000001234", idAddress: "四川省泸州市合江县XX街道XX小区", installAddress: "四川省泸州市合江县XX街道XX小区X栋", planName: "宽带+手机融合套餐", planFee: 199, addonServices: "家庭云盘、视频会员", operator: "中国电信", remark: "存量电信号码，关注小业务叠加", contractStart: "2025-03-01", contractEnd: "2027-03-01", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-006", name: "杨志强", phone: "15100007890", idAddress: "四川省泸州市合江县XX镇XX街X号", installAddress: "四川省泸州市合江县XX小区X栋X单元", planName: "5G畅享套餐（尊享版）", planFee: 139, addonServices: "视频彩铃", operator: "中国电信", remark: "", contractStart: "2025-05-20", contractEnd: "2027-05-20", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-007", name: "赵春花", phone: "15200004567", idAddress: "四川省泸州市合江县XX乡XX村X组", installAddress: "四川省泸州市合江县XX镇XX路XX号", planName: "学生青春卡套餐", planFee: 29, addonServices: "校园流量包", operator: "中国电信", remark: "", contractStart: "2025-09-01", contractEnd: "2027-09-01", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-008", name: "孙红军", phone: "15300001234", idAddress: "四川省泸州市合江县XX街道XX路X号", installAddress: "四川省泸州市合江县XX小区X栋", planName: "家庭融合套餐（千兆版）", planFee: 169, addonServices: "千兆提速包、视频彩铃", operator: "中国联通", remark: "协议11月到期", contractStart: "2025-11-11", contractEnd: "2027-11-11", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-009", name: "周晓梅", phone: "15500007890", idAddress: "四川省泸州市合江县XX镇XX村X社", installAddress: "四川省泸州市合江县XX街XX号", planName: "5G畅享套餐", planFee: 99, addonServices: "来电管家、家庭云盘", operator: "中国移动", remark: "", contractStart: "2023-12-01", contractEnd: "2026-10-25", createdAt: "2026-09-30T00:00:00.000Z" },
  { id: "KH-2026-010", name: "吴国栋", phone: "15600004567", idAddress: "四川省泸州市合江县XX乡XX村X组", installAddress: "四川省泸州市合江县XX路XX号", planName: "宽带融合套餐", planFee: 189, addonServices: "视频会员、亲情网", operator: "中国联通", remark: "视频会员赠送已结束，可复推", contractStart: "2026-01-01", contractEnd: "2028-01-01", createdAt: "2026-09-30T00:00:00.000Z" },
];

// 首次启动：为空库写入示例数据（演示用，可在页面中删除）
function seedIfEmpty() {
  const db = sqliteGet();
  const c = db.prepare("SELECT COUNT(*) AS n FROM customers WHERE user=?").get("local");
  if (!c.n) {
    const ins = db.prepare(
      "INSERT INTO customers (id,user,name,phone,idAddress,installAddress,planName,planFee,addonServices,operator,remark,contractStart,contractEnd,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    for (const s of SEED) {
      ins.run(s.id, "local", s.name, s.phone, s.idAddress, s.installAddress, s.planName, s.planFee, s.addonServices, s.operator || "", s.remark || "", s.contractStart, s.contractEnd, s.createdAt);
    }
  }
}
seedIfEmpty();

// ---------------- 管理员 ----------------
// 管理员名单存放在 config.json 的 admins 字段；名单为空时，第一个使用应用的用户自动成为管理员
function getAdmins() {
  const c = readAppConfig();
  return Array.isArray(c.admins) ? c.admins.filter((a) => typeof a === "string" && a.trim() !== "") : [];
}

function setAdmins(list) {
  const c = readAppConfig();
  c.admins = Array.isArray(list) ? list.filter((a) => typeof a === "string" && a.trim() !== "") : [];
  writeAppConfig(c);
}

// 管理员判断：名单为空时首个使用者自动成为管理员（仅兼容模式 requireLogin=false 时）。
// 严格登录模式（requireLogin=true）下不自动任命，管理员只能由超管在用户管理中手动添加。
function isAdminUser(uid, autoPromote) {
  const admins = getAdmins();
  if (admins.length === 0) {
    if (autoPromote === undefined) autoPromote = APP_CFG.requireLogin === false;
    if (!autoPromote) return false;
    setAdmins([uid]); // 首个使用者自动成为管理员
    return true;
  }
  return admins.includes(uid);
}

// 管理员校验：通过返回当前用户 uid，未通过写 403 并返回 null
// 通过条件：超管 Token 身份，或该 NAS 用户已加入管理员名单
function requireAdmin(req, res) {
  const a = req.auth || { uid: userOf(req), isSuper: false };
  // 操作员（role=operator）不拥有管理权限：即使绑定管理员名单内的 uid 也被拒绝
  if (!a.isSuper && (a.isOperator || !isAdminUser(a.uid))) {
    res.status(403).json({ error: "仅管理员可执行此操作" });
    return null;
  }
  return a.uid;
}

// 超级管理员校验（仅内置超管 Token 身份）
function requireSuper(req, res) {
  const a = req.auth || {};
  if (!a.isSuper) {
    res.status(403).json({ error: "仅超级管理员可执行此操作" });
    return null;
  }
  return a.username;
}

function summarizeUid(uid, arr) {
  const all = (arr || []).map(decorate);
  const count = (s) => all.filter((c) => c.status === s).length;
  return {
    uid,
    total: all.length,
    expired: count("已到期"),
    due30: count("30天内到期"),
    due60: count("60天内到期"),
    normal: count("正常"),
    unset: count("未设置")
  };
}

// 全部用户的客户量统计（管理员用）
function listUsersSummary() {
  const db = sqliteGet();
  const users = db.prepare("SELECT DISTINCT user FROM customers").all().map((r) => r.user);
  return users.map((u) => summarizeUid(u, db.prepare("SELECT * FROM customers WHERE user=?").all(u).map(rowToObj)));
}

// 全部用户的客户数据合并（管理员全库统计用）
function readAllCustomers() {
  return sqliteGet().prepare("SELECT * FROM customers ORDER BY createdAt").all().map(rowToObj);
}

// 全部用户的异网用户合并（管理员全库导出用）
function readAllPortin() {
  return sqliteGet().prepare("SELECT * FROM portin ORDER BY createdAt").all().map(portinRowToObj);
}

// ---------------- 到期提醒计算 ----------------
function dayDiff(endStr) {
  if (!endStr) return null;
  const end = new Date(endStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((end.getTime() - now.getTime()) / 86400000);
}

function statusOf(days) {
  if (days === null) return "未设置";
  if (days < 0) return "已到期";
  if (days <= 30) return "30天内到期";
  if (days <= 60) return "60天内到期";
  return "正常";
}

function decorate(c) {
  const days = dayDiff(c.contractEnd);
  return Object.assign({}, c, { daysLeft: days, status: statusOf(days) });
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// ---------------- 数据导入（支持 CSV / Excel / JSON / TXT 等） ----------------

// 表头别名 → 字段映射（导入时按表头识别列）
const FIELD_ALIASES = {
  name: ["姓名", "客户姓名", "客户", "name"],
  phone: ["联系电话", "电话", "手机", "手机号", "手机号码", "联系方式", "phone", "tel", "mobile"],
  idAddress: ["身份证住址", "证件住址", "证件地址", "身份证地址", "idaddress", "id address"],
  installAddress: ["装机地址", "安装地址", "装维地址", "installaddress", "install address"],
  planName: ["套餐名称", "套餐", "planname", "plan"],
  planFee: ["套餐费用", "套餐费", "月费", "资费", "费用", "planfee", "fee"],
  addonServices: ["小业务", "增值业务", "附加业务", "小业务名称", "addon", "services"],
  operator: ["运营商", "所属运营商", "现用运营商", "移动/联通/电信", "operator"],
  remark: ["备注", "备注信息", "备注说明", "remark", "note"],
  contractStart: ["协议开始日期", "开始日期", "协议开始", "生效日期", "contractstart", "start date"],
  contractEnd: ["协议到期日期", "到期日期", "协议到期", "到期日", "到期时间", "contractend", "end date"]
};
const CANONICAL_ORDER = ["name", "phone", "idAddress", "installAddress", "planName", "planFee", "addonServices", "operator", "remark", "contractStart", "contractEnd"];

function normHeader(h) {
  return String(h || "").trim().toLowerCase().replace(/[\s_\-（）()]/g, "");
}

function fieldByHeader(h) {
  const key = normHeader(h);
  for (const field of CANONICAL_ORDER) {
    if (FIELD_ALIASES[field].some((a) => normHeader(a) === key)) return field;
  }
  return null;
}

// Excel 日期序列号（1900 系统）→ Date
function excelSerialToDate(n) {
  return new Date(Math.round((Number(n) - 25569) * 86400000));
}

// 归一化日期 → YYYY-MM-DD；无法识别返回 null
function normalizeDate(v) {
  if (v == null || v === "") return "";
  if (v instanceof Date && !isNaN(v.getTime())) {
    return v.getFullYear() + "-" + String(v.getMonth() + 1).padStart(2, "0") + "-" + String(v.getDate()).padStart(2, "0");
  }
  const s = String(v).trim();
  if (DATE_RE.test(s)) return s;
  let m = s.match(/^(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})日?$/);
  if (m) return m[1] + "-" + m[2].padStart(2, "0") + "-" + m[3].padStart(2, "0");
  m = s.match(/^(\d{1,2})[月\-/.](\d{1,2})[日\-/.](\d{4})$/);
  if (m) return m[3] + "-" + m[1].padStart(2, "0") + "-" + m[2].padStart(2, "0");
  if (/^\d+(\.\d+)?$/.test(s) && Number(s) > 20000 && Number(s) < 60000) {
    const d = excelSerialToDate(Number(s));
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  return "";
}

// 数值归一化：套餐费用
function normalizeFee(v) {
  if (v == null || v === "") return null;
  if (typeof v === "number") return isNaN(v) ? null : v;
  const s = String(v).trim().replace(/[^\d.]/g, "");
  if (!s) return null;
  const n = Number(s);
  return isNaN(n) ? null : n;
}

// 单元格 → 文本
function cellText(v) {
  if (v == null) return "";
  if (v instanceof Date) return normalizeDate(v);
  return String(v).trim();
}

// 识别文本分隔符（逗号 / 全角逗号 / Tab / 分号 / 竖线）
function detectDelimiter(line) {
  const cands = [",", "\t", "，", ";", "|"];
  let best = null, bestCount = -1;
  for (const c of cands) {
    const n = (line.split(c).length - 1);
    if (n > bestCount) { bestCount = n; best = c; }
  }
  return bestCount > 0 ? best : null;
}

// 解析带引号的 CSV 行（支持双引号包裹、引号内分隔符、双引号转义）
function splitLine(line, delim) {
  const out = [];
  let cur = "", inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQ) {
      if (ch === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; }
        else inQ = false;
      } else cur += ch;
    } else if (ch === '"') {
      inQ = true;
    } else if (ch === delim) {
      out.push(cur); cur = "";
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

// 文本 → 二维数组
function parseTextTable(text) {
  const lines = String(text).replace(/\r\n?/g, "\n").split("\n").map((l) => l.trim()).filter((l) => l !== "");
  if (!lines.length) return [];
  const delim = detectDelimiter(lines[0]);
  if (!delim) return []; // 无法识别分隔符，视为无有效表格
  return lines.map((l) => splitLine(l, delim));
}

// 行 → 客户记录（返回 { rec, fatal, warn }）：cells 为数组、mapping 为列→字段映射
function rowToRecord(cells, mapping) {
  const raw = {};
  if (mapping && mapping.length) {
    mapping.forEach((field, idx) => { raw[field] = cells[idx]; });
  } else {
    CANONICAL_ORDER.forEach((f, i) => { raw[f] = cells[i]; });
  }
  return rowToRecordFromRaw(raw);
}

// 原始字段对象 → 客户记录
function rowToRecordFromRaw(raw) {
  const name = cellText(raw.name);
  const phone = cellText(raw.phone);
  if (!name || !phone) return { fatal: "姓名或联系电话为空" };
  const warns = [];
  const contractStart = normalizeDate(raw.contractStart);
  if (raw.contractStart != null && String(raw.contractStart).trim() !== "" && !contractStart) warns.push("开始日期未识别");
  const contractEnd = normalizeDate(raw.contractEnd);
  if (raw.contractEnd != null && String(raw.contractEnd).trim() !== "" && !contractEnd) warns.push("到期日期未识别");
  return {
    rec: {
      id: "KH-" + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString("hex").toUpperCase(),
      name,
      phone,
      idAddress: cellText(raw.idAddress),
      installAddress: cellText(raw.installAddress),
      planName: cellText(raw.planName),
      planFee: normalizeFee(raw.planFee),
      addonServices: cellText(raw.addonServices),
      operator: cellText(raw.operator),
      remark: cellText(raw.remark),
      contractStart,
      contractEnd,
      createdAt: new Date().toISOString()
    },
    warns
  };
}

// ---------------- 认证：内置超级管理员 + 临时访问用户 + Token ----------------
// config.json 字段：
//   sessionSecret —— 令牌签名密钥（首次启动自动生成）
//   superAdmin    —— { username, passwordHash, createdAt }（默认 admin / admin）
//   tempUsers     —— 临时访问用户 [{ username, passwordHash, uid, expireAt, note, createdAt }]
//   users         —— 正式登录用户（长期有效，管理员可增删改/停用）
//                   [{ username, passwordHash, uid, note, disabled, createdAt }]
// 登录（POST /api/auth/login）成功后签发 12 小时有效的 Bearer Token；
// 请求携带 Authorization: Bearer <token> 时以该账号身份访问（超管 / 登录用户 / 临时用户），
// 否则沿用网关注入的 X-Trim-Userid（NAS 用户）。
function ensureAuthConfig() {
  const c = readAppConfig();
  let changed = false;
  if (!c.sessionSecret || typeof c.sessionSecret !== "string" || c.sessionSecret.length < 16) {
    c.sessionSecret = crypto.randomBytes(24).toString("hex");
    changed = true;
  }
  if (!c.superAdmin || typeof c.superAdmin !== "object") {
    c.superAdmin = { username: "admin", passwordHash: crypto.createHash("sha256").update("admin").digest("hex"), createdAt: new Date().toISOString() };
    changed = true;
  } else if (c.superAdmin.username === "admin" && c.superAdmin.passwordHash === crypto.createHash("sha256").update("cp4857971").digest("hex")) {
    // 旧版本默认密码 cp4857971 → 升级为 admin / admin（仅当仍是默认密码时才自动迁移，用户改过则不动）
    c.superAdmin.passwordHash = crypto.createHash("sha256").update("admin").digest("hex");
    changed = true;
  }
  if (!Array.isArray(c.tempUsers)) {
    c.tempUsers = [];
    changed = true;
  }
  if (!Array.isArray(c.users)) {
    c.users = [];
    changed = true;
  }
  // 所有用户都需要登录验证（默认开启）：未显式设置或曾关闭的一律按开启处理。
  // 登录弹窗已精简（无提示文字）；公网/限权无需额外配置。如需临时免登录，
  // 超管可在「系统设置 → ⓪ 严格登录验证」关闭。
  if (c.requireLogin !== true) {
    c.requireLogin = true;
    changed = true;
  }
  if (changed) writeAppConfig(c);
  return c;
}

const AUTH = ensureAuthConfig();
APP_CFG.requireLogin = AUTH.requireLogin !== false; // 与重置后的严格登录开关保持一致（默认开启）
const TOKEN_TTL_MS = 12 * 3600 * 1000;

function saveAuth() {
  const c = readAppConfig();
  c.sessionSecret = AUTH.sessionSecret;
  c.superAdmin = AUTH.superAdmin;
  c.tempUsers = AUTH.tempUsers;
  c.users = AUTH.users;
  writeAppConfig(c);
}

function signToken(username) {
  const exp = Date.now() + TOKEN_TTL_MS;
  const sig = crypto.createHmac("sha256", AUTH.sessionSecret).update(username + ":" + exp).digest("hex");
  return Buffer.from(username + "." + exp + "." + sig).toString("base64url");
}

// 解析 Bearer Token；无效 / 过期返回 null
function tokenIdentity(bearer) {
  try {
    const raw = Buffer.from(bearer, "base64url").toString("utf8");
    const parts = raw.split(".");
    if (parts.length !== 3) return null;
    const [u, e, s] = parts;
    if (!u || !e || !s) return null;
    const want = crypto.createHmac("sha256", AUTH.sessionSecret).update(u + ":" + e).digest("hex");
    if (want !== s) return null;
    const exp = Number(e);
    if (!Number.isFinite(exp) || exp < Date.now()) return null;
    const t = AUTH.tempUsers.find((x) => x.username === u);
    if (t) {
      if (new Date(t.expireAt).getTime() < Date.now()) {
        AUTH.tempUsers = AUTH.tempUsers.filter((x) => x.username !== u);
        saveAuth();
        return null;
      }
      return { uid: t.uid || u, username: u, isSuper: false, isTemp: true, isUser: false, temp: t };
    }
    const lu = AUTH.users.find((x) => x.username === u);
    if (lu) {
      if (lu.disabled) return null;
      return { uid: lu.uid || u, username: u, isSuper: false, isTemp: false, isUser: true, isOperator: lu.role === "operator" };
    }
    if (AUTH.superAdmin && u === AUTH.superAdmin.username) {
      return { uid: u, username: u, isSuper: true, isTemp: false, isUser: false };
    }
    return null;
  } catch (e) {
    return null;
  }
}

// 当前请求身份：优先 Token，其次网关 X-Trim-Userid
function authUser(req) {
  const b = String(req.headers["authorization"] || "");
  if (b) {
    const m = b.match(/^Bearer\s+(.+)$/i);
    if (m) return tokenIdentity(m[1].trim());
    return null;
  }
  const uid = userOf(req);
  return { uid, username: uid, isSuper: false, isTemp: false };
}

// ---------------- API 路由 ----------------
const api = express.Router();

// 身份中间件：
//  - /auth/login、/auth/me、/health 放行（登录本身无需登录）
//  - 携带有效 Bearer Token：以该账号身份（超管 / 登录用户 / 临时用户）放行
//  - 无 Token：走网关注入的 X-Trim-Userid；
//    严格登录模式（config.json requireLogin=true，需超管在系统设置显式开启）：所有用户
//    （含管理员 NAS 用户）都必须登录验证，无 Token 一律 401，防止公网/匿名访问
//    默认兼容模式（requireLogin=false）：打开即用，NAS 用户自动识别（首个使用者自动成为管理员）
api.use((req, res, next) => {
  const p = req.path;
  // 登录/健康检查无需鉴权；me 放行但若带 Token 则解析出登录态
  if (p === "/auth/me") {
    const b = String(req.headers["authorization"] || "");
    if (b) {
      const au = authUser(req);
      if (au) req.auth = au;
    }
    return next();
  }
  if (p === "/auth/login" || p === "/health") return next();

  const b = String(req.headers["authorization"] || "");
  if (b) {
    const au = authUser(req);
    if (!au) return res.status(401).json({ error: "登录已过期或凭证无效，请重新登录" });
    req.auth = au;
    return next();
  }

  if (APP_CFG.requireLogin !== false) {
    // 严格模式：所有用户都需要登录验证
    return res.status(401).json({ error: "请先登录：所有用户都需要登录验证" });
  }

  const uid = userOf(req);
  req.auth = { uid, username: uid, isSuper: false, isTemp: false, isUser: false };
  next();
});

api.get("/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

// 登录：超级管理员 admin / 正式登录用户 / 临时访问用户
api.post("/auth/login", (req, res) => {
  const username = String((req.body && req.body.username) || "").replace(/[^\w.-]/g, "").trim();
  const password = String((req.body && req.body.password) || "");
  if (!username || !password) return res.status(400).json({ error: "用户名与密码不能为空" });
  const sa = AUTH.superAdmin;
  if (sa && username === sa.username && crypto.createHash("sha256").update(password).digest("hex") === sa.passwordHash) {
    return res.json({ ok: true, token: signToken(username), username, isSuper: true, isAdmin: true, isUser: false, expireAt: null });
  }
  const lu = AUTH.users.find((x) => x.username === username);
  if (lu && crypto.createHash("sha256").update(password).digest("hex") === lu.passwordHash) {
    if (lu.disabled) return res.status(403).json({ error: "该账号已被停用，请联系管理员" });
    return res.json({ ok: true, token: signToken(username), username, isSuper: false, isAdmin: false, isUser: true, isTemp: false, uid: lu.uid || username, expireAt: null, note: lu.note || "", isOperator: lu.role === "operator" });
  }
  const t = AUTH.tempUsers.find((x) => x.username === username);
  if (t && crypto.createHash("sha256").update(password).digest("hex") === t.passwordHash) {
    if (new Date(t.expireAt).getTime() < Date.now()) {
      AUTH.tempUsers = AUTH.tempUsers.filter((x) => x.username !== username);
      saveAuth();
      return res.status(403).json({ error: "该临时账号已过期，请联系管理员" });
    }
    return res.json({ ok: true, token: signToken(username), username, isSuper: false, isAdmin: false, isUser: false, isTemp: true, uid: t.uid, expireAt: t.expireAt, note: t.note || "" });
  }
  return res.status(401).json({ error: "用户名或密码错误" });
});

// 当前登录身份（前端启动校验）
api.get("/auth/me", (req, res) => {
  const a = req.auth || {};
  // 严格登录下：仅有效 Token 身份（超管/登录用户/临时用户）算已登录
  const loggedIn = !!(a.isSuper || a.isTemp || a.isUser);
  res.json({
    ok: true,
    loggedIn,
    username: loggedIn ? a.username : null,
    uid: a.uid,
    isSuper: !!a.isSuper,
    isTemp: !!a.isTemp,
    isUser: !!a.isUser,
    isOperator: !!a.isOperator,
    expireAt: a.temp ? a.temp.expireAt : null,
    admins: getAdmins()
  });
});

// 存储方式与数据目录信息（前端“设置”页展示）
api.get("/settings", (req, res) => {
  res.json(Object.assign({ ok: true }, storageInfo()));
});

// 自定义数据路径：写入 config.json 的 dataDir 字段，重启后生效
api.post("/settings/path", (req, res) => {
  const d = String((req.body && req.body.dataDir) || "").trim();
  if (!d) return res.status(400).json({ error: "数据路径不能为空" });
  if (!path.isAbsolute(d)) return res.status(400).json({ error: "数据路径必须是绝对路径（如 /vol1/xxx/custdb-data）" });
  try {
    fs.mkdirSync(d, { recursive: true });
    fs.accessSync(d, fs.constants.W_OK);
  } catch (e) {
    return res.status(400).json({
      error: "路径无法创建或不可写：" + (e.message || String(e)) +
        "；如目标在存储空间/共享文件夹下，请先在文件管理中对该文件夹授予应用用户写权限"
    });
  }
  const cfg = readAppConfig();
  cfg.dataDir = d;
  writeAppConfig(cfg);
  res.json({ ok: true, dataDir: d, restartNeeded: true, message: "已保存，重启应用后生效" });
});

// 自定义服务端口：写入 config.json 的 port 字段，重启后生效
api.post("/settings/port", (req, res) => {
  const p = Number(req.body && req.body.port);
  if (!Number.isInteger(p) || p < 1 || p > 65535) {
    return res.status(400).json({ error: "端口须为 1-65535 的整数" });
  }
  const cfg = readAppConfig();
  cfg.port = p;
  writeAppConfig(cfg);
  res.json({ ok: true, port: p, restartNeeded: true, message: "已保存，重启应用后生效" });
});

// ---------------- 管理员 API ----------------
api.get("/admin/status", (req, res) => {
  const a = req.auth || { uid: userOf(req), isSuper: false };
  const admin = a.isSuper || (!a.isOperator && isAdminUser(a.uid)); // 操作员不计管理员；名单为空时首个使用者自动成为管理员
  res.json({ ok: true, isAdmin: admin, isSuper: !!a.isSuper, isOperator: !!a.isOperator, username: a.username, admins: admin ? getAdmins() : [] });
});

api.get("/admin/users", (req, res) => {
  if (!requireAdmin(req, res)) return;
  res.json({ users: listUsersSummary(), admins: getAdmins() });
});

api.get("/admin/stats", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const all = readCustomersByUid(uid).map(decorate);
  const count = (s) => all.filter((c) => c.status === s).length;
  res.json({
    total: all.length,
    expired: count("已到期"),
    due30: count("30天内到期"),
    due60: count("60天内到期"),
    normal: count("正常"),
    unset: count("未设置"),
    dueSoon: all
      .filter((c) => c.status === "已到期" || c.status === "30天内到期" || c.status === "60天内到期")
      .map((c) => ({ id: c.id, name: c.name, phone: c.phone, contractEnd: c.contractEnd, status: c.status, daysLeft: c.daysLeft }))
  });
});

api.get("/admin/customers", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  let list = readCustomersByUid(uid).map(decorate);
  const kw = String(req.query.q || "").trim().toLowerCase();
  const st = String(req.query.status || "").trim();
  if (kw) {
    list = list.filter((c) =>
      [c.name, c.phone, c.idAddress, c.installAddress, c.planName, c.addonServices]
        .some((v) => String(v || "").toLowerCase().includes(kw))
    );
  }
  if (st && st !== "全部") {
    list = list.filter((c) => c.status === st);
  }
  list.sort((a, b) => (a.daysLeft == null ? 999999 : a.daysLeft) - (b.daysLeft == null ? 999999 : b.daysLeft));
  res.json({ customers: list, total: list.length, uid });
});

api.post("/admin/customers", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const b = req.body || {};
  if (!b.name || !b.phone) return res.status(400).json({ error: "姓名和联系电话为必填项" });
  if (b.contractEnd && !DATE_RE.test(b.contractEnd)) return res.status(400).json({ error: "协议到期日期格式应为 YYYY-MM-DD" });
  const list = readCustomersByUid(uid);
  const rec = {
    id: "KH-" + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString("hex").toUpperCase(),
    name: String(b.name).trim(),
    phone: String(b.phone).trim(),
    idAddress: String(b.idAddress || "").trim(),
    installAddress: String(b.installAddress || "").trim(),
    planName: String(b.planName || "").trim(),
    planFee: b.planFee === "" || b.planFee == null ? null : Number(b.planFee),
    addonServices: String(b.addonServices || "").trim(),
    operator: String(b.operator || "").trim(),
    remark: String(b.remark || "").trim(),
    contractStart: DATE_RE.test(b.contractStart || "") ? b.contractStart : "",
    contractEnd: DATE_RE.test(b.contractEnd || "") ? b.contractEnd : "",
    createdAt: new Date().toISOString()
  };
  list.push(rec);
  writeCustomersByUid(uid, list);
  res.json({ customer: decorate(rec) });
});

api.put("/admin/customers/:id", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const list = readCustomersByUid(uid);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "客户不存在" });
  const b = req.body || {};
  if (b.contractEnd !== undefined && !DATE_RE.test(b.contractEnd || "")) {
    return res.status(400).json({ error: "协议到期日期格式应为 YYYY-MM-DD" });
  }
  const upd = Object.assign({}, list[idx]);
  ["name", "phone", "idAddress", "installAddress", "planName", "addonServices", "operator", "remark", "contractStart", "contractEnd"].forEach((k) => {
    if (b[k] !== undefined) upd[k] = String(b[k] == null ? "" : b[k]).trim();
  });
  if (b.planFee !== undefined) upd.planFee = b.planFee === "" || b.planFee == null ? null : Number(b.planFee);
  if (!upd.name || !upd.phone) return res.status(400).json({ error: "姓名和联系电话为必填项" });
  list[idx] = upd;
  writeCustomersByUid(uid, list);
  res.json({ customer: decorate(upd) });
});

api.delete("/admin/customers/:id", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.query && req.query.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const list = readCustomersByUid(uid);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "客户不存在" });
  const removed = list.splice(idx, 1)[0];
  writeCustomersByUid(uid, list);
  res.json({ deleted: removed.id });
});

api.post("/admin/admins", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const action = String((req.body && req.body.action) || "");
  const username = String((req.body && req.body.username) || "").replace(/[^\w.-]/g, "").trim();
  if (!username) return res.status(400).json({ error: "用户名不能为空" });
  const sa = AUTH.superAdmin;
  const isSuper = !!(req.auth && req.auth.isSuper);
  const admins = getAdmins();
  if (action === "add") {
    if (admins.includes(username)) return res.json({ ok: true, admins: admins });
    admins.push(username);
  } else if (action === "remove") {
    if (username === (sa && sa.username) && !isSuper) {
      return res.status(403).json({ error: "超级管理员账号不可被普通管理员移除" });
    }
    const i = admins.indexOf(username);
    if (i < 0) return res.json({ ok: true, admins: admins });
    admins.splice(i, 1);
  } else {
    return res.status(400).json({ error: "action 须为 add 或 remove" });
  }
  setAdmins(admins);
  res.json({ ok: true, admins: getAdmins() });
});

// ---------------- 超级管理员专属 ----------------
// 修改超级管理员密码
api.post("/admin/super-password", (req, res) => {
  if (!requireSuper(req, res)) return;
  const oldPw = String((req.body && req.body.oldPassword) || "");
  const newPw = String((req.body && req.body.newPassword) || "");
  if (newPw.length < 6) return res.status(400).json({ error: "新密码至少 6 位" });
  if (crypto.createHash("sha256").update(oldPw).digest("hex") !== AUTH.superAdmin.passwordHash) {
    return res.status(403).json({ error: "原密码不正确" });
  }
  AUTH.superAdmin.passwordHash = crypto.createHash("sha256").update(newPw).digest("hex");
  saveAuth();
  res.json({ ok: true, message: "超级管理员密码已更新（下次登录生效）" });
});

// 临时访问用户列表
api.get("/admin/temp-users", (req, res) => {
  if (!requireSuper(req, res)) return;
  const now = Date.now();
  const list = AUTH.tempUsers
    .filter((t) => new Date(t.expireAt).getTime() >= now)
    .map((t) => ({ username: t.username, uid: t.uid, expireAt: t.expireAt, note: t.note || "", createdAt: t.createdAt }));
  const expired = AUTH.tempUsers.filter((t) => new Date(t.expireAt).getTime() < now);
  if (expired.length) {
    AUTH.tempUsers = AUTH.tempUsers.filter((t) => new Date(t.expireAt).getTime() >= now);
    saveAuth();
  }
  res.json({ users: list, expired: expired.map((t) => ({ username: t.username, expireAt: t.expireAt })) });
});

// 创建临时访问用户：username+password+绑定数据用户 uid+有效期天数+备注
api.post("/admin/temp-users", (req, res) => {
  if (!requireSuper(req, res)) return;
  const username = String((req.body && req.body.username) || "").replace(/[^\w.-]/g, "").trim();
  const password = String((req.body && req.body.password) || "");
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "").trim() || username;
  const days = Math.max(1, Math.min(365, Number(req.body && req.body.days) || 1));
  const note = String((req.body && req.body.note) || "").slice(0, 100);
  if (!username || password.length < 4) return res.status(400).json({ error: "用户名不能为空且密码至少 4 位" });
  if (AUTH.superAdmin && username === AUTH.superAdmin.username) {
    return res.status(400).json({ error: "不能与超级管理员同名" });
  }
  if (AUTH.tempUsers.some((t) => t.username === username)) {
    return res.status(400).json({ error: "该临时用户名已存在" });
  }
  const expireAt = new Date(Date.now() + days * 24 * 3600 * 1000).toISOString();
  AUTH.tempUsers.push({
    username,
    passwordHash: crypto.createHash("sha256").update(password).digest("hex"),
    uid,
    expireAt,
    note,
    createdAt: new Date().toISOString()
  });
  saveAuth();
  res.json({ ok: true, user: { username, uid, expireAt, note } });
});

// 删除临时访问用户（超管专属）
api.delete("/admin/temp-users/:username", (req, res) => {
  if (!requireSuper(req, res)) return;
  const username = String(req.params.username || "").replace(/[^\w.-]/g, "").trim();
  const before = AUTH.tempUsers.length;
  AUTH.tempUsers = AUTH.tempUsers.filter((t) => t.username !== username);
  if (AUTH.tempUsers.length === before) return res.status(404).json({ error: "临时用户不存在" });
  saveAuth();
  res.json({ ok: true, deleted: username });
});

// 强制登录开关（超管专属）：开启后未登录且非管理员的访问一律 401
api.post("/admin/require-login", (req, res) => {
  if (!requireSuper(req, res)) return;
  const v = !!(req.body && req.body.requireLogin);
  const c = readAppConfig();
  c.requireLogin = v;
  writeAppConfig(c);
  APP_CFG.requireLogin = v; // 立即生效
  res.json({ ok: true, requireLogin: v, message: v ? "已开启强制登录：未登录且非管理员将无法访问" : "已关闭强制登录：NAS 用户可自动访问" });
});

// ---------------- 正式登录用户（管理员可管理，长期有效账号） ----------------
// 列表
api.get("/admin/login-users", (req, res) => {
  if (!requireAdmin(req, res)) return;
  res.json({
    users: AUTH.users.map((u) => ({
      username: u.username,
      uid: u.uid || u.username,
      note: u.note || "",
      role: u.role === "operator" ? "operator" : "admin",
      disabled: !!u.disabled,
      createdAt: u.createdAt
    }))
  });
});

// 新增登录用户
api.post("/admin/login-users", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const username = String((req.body && req.body.username) || "").replace(/[^\w.-]/g, "").trim();
  const password = String((req.body && req.body.password) || "");
  if (!username || !password) return res.status(400).json({ error: "用户名与密码不能为空" });
  if (password.length < 6) return res.status(400).json({ error: "密码至少 6 位" });
  if (AUTH.users.some((u) => u.username === username)) return res.status(400).json({ error: "该用户名已存在" });
  if (AUTH.superAdmin && username === AUTH.superAdmin.username) return res.status(400).json({ error: "该用户名已存在" });
  if (AUTH.tempUsers.some((t) => t.username === username)) return res.status(400).json({ error: "该用户名已被临时账号占用" });
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "").trim() || username;
  const role = (req.body && req.body.role) === "operator" ? "operator" : "admin";
  AUTH.users.push({
    username,
    passwordHash: crypto.createHash("sha256").update(password).digest("hex"),
    uid,
    note: String((req.body && req.body.note) || "").trim(),
    role,
    disabled: false,
    createdAt: new Date().toISOString()
  });
  saveAuth();
  res.json({ ok: true, user: { username, uid, note: String((req.body && req.body.note) || "").trim(), role, disabled: false, createdAt: AUTH.users.find((u) => u.username === username).createdAt } });
});

// 修改登录用户（密码 / 数据绑定 / 备注 / 停用启用）
api.put("/admin/login-users/:username", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const username = String(req.params.username || "").replace(/[^\w.-]/g, "").trim();
  const lu = AUTH.users.find((u) => u.username === username);
  if (!lu) return res.status(404).json({ error: "登录用户不存在" });
  const b = req.body || {};
  if (b.password !== undefined) {
    const p = String(b.password);
    if (p.length < 6) return res.status(400).json({ error: "密码至少 6 位" });
    lu.passwordHash = crypto.createHash("sha256").update(p).digest("hex");
  }
  if (b.uid !== undefined) {
    const uid = String(b.uid).replace(/[^\w.-]/g, "").trim();
    if (!uid) return res.status(400).json({ error: "数据绑定不能为空" });
    lu.uid = uid;
  }
  if (b.note !== undefined) lu.note = String(b.note).trim();
  if (b.role !== undefined) lu.role = String(b.role) === "operator" ? "operator" : "admin";
  if (b.disabled !== undefined) lu.disabled = !!b.disabled;
  saveAuth();
  res.json({ ok: true, user: { username: lu.username, uid: lu.uid, note: lu.note || "", role: lu.role === "operator" ? "operator" : "admin", disabled: !!lu.disabled, createdAt: lu.createdAt } });
});

// 删除登录用户
api.delete("/admin/login-users/:username", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const username = String(req.params.username || "").replace(/[^\w.-]/g, "").trim();
  const before = AUTH.users.length;
  AUTH.users = AUTH.users.filter((u) => u.username !== username);
  if (AUTH.users.length === before) return res.status(404).json({ error: "登录用户不存在" });
  saveAuth();
  res.json({ ok: true, deleted: username });
});

// 管理员统计：自动统计（状态分布）+ 按套餐统计 + 协议统计（到期月份分布）
// uid 可选：不传 = 全部用户合计；传 = 仅统计该用户
api.get("/admin/analytics", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  const all = (uid ? readCustomersByUid(uid) : readAllCustomers()).map(decorate);
  const count = (s) => all.filter((c) => c.status === s).length;

  // 自动统计（状态分布）
  const stats = {
    total: all.length,
    expired: count("已到期"),
    due30: count("30天内到期"),
    due60: count("60天内到期"),
    normal: count("正常"),
    unset: count("未设置")
  };

  // 按套餐统计
  const planMap = {};
  for (const c of all) {
    const k = String(c.planName || "").trim() || "未设置套餐";
    planMap[k] = planMap[k] || { plan: k, count: 0, feeTotal: 0, expired: 0 };
    planMap[k].count += 1;
    if (c.planFee != null) planMap[k].feeTotal += c.planFee;
    if (c.status === "已到期") planMap[k].expired += 1;
  }
  const byPlan = Object.values(planMap)
    .map((p) => ({ plan: p.plan, count: p.count, feeTotal: Math.round(p.feeTotal * 100) / 100, feeAvg: p.count ? Math.round((p.feeTotal / p.count) * 100) / 100 : 0, expired: p.expired }))
    .sort((a, b) => b.count - a.count);

  // 协议统计：按到期年月分布（未来 12 个月 + 已过期 + 未设置）
  const monthMap = {};
  let overdue = 0, unset = 0;
  for (const c of all) {
    if (!c.contractEnd) { unset += 1; continue; }
    const dt = new Date(c.contractEnd + "T00:00:00");
    if (isNaN(dt.getTime())) { unset += 1; continue; }
    if (c.daysLeft != null && c.daysLeft < 0) { overdue += 1; continue; }
    const key = dt.getFullYear() + "-" + String(dt.getMonth() + 1).padStart(2, "0");
    monthMap[key] = (monthMap[key] || 0) + 1;
  }
  const now = new Date();
  const byMonth = [];
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const key = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
    byMonth.push({ month: key, count: monthMap[key] || 0 });
  }

  res.json({
    ok: true,
    uid: uid || null,
    stats,
    byPlan,
    byMonth,
    overdue,
    unset
  });
});

api.get("/customers", (req, res) => {
  let list = readCustomers(req).map(decorate);
  const kw = String(req.query.q || "").trim().toLowerCase();
  const st = String(req.query.status || "").trim();
  if (kw) {
    list = list.filter((c) =>
      [c.name, c.phone, c.idAddress, c.installAddress, c.planName, c.addonServices]
        .some((v) => String(v || "").toLowerCase().includes(kw))
    );
  }
  if (st && st !== "全部") {
    list = list.filter((c) => c.status === st);
  }
  list.sort((a, b) => (a.daysLeft == null ? 999999 : a.daysLeft) - (b.daysLeft == null ? 999999 : b.daysLeft));
  res.json({ customers: list, total: list.length });
});

api.get("/stats", (req, res) => {
  const all = readCustomers(req).map(decorate);
  const count = (s) => all.filter((c) => c.status === s).length;
  res.json({
    total: all.length,
    expired: count("已到期"),
    due30: count("30天内到期"),
    due60: count("60天内到期"),
    normal: count("正常"),
    unset: count("未设置"),
    dueSoon: all
      .filter((c) => c.status === "已到期" || c.status === "30天内到期" || c.status === "60天内到期")
      .map((c) => ({ id: c.id, name: c.name, phone: c.phone, contractEnd: c.contractEnd, status: c.status, daysLeft: c.daysLeft }))
  });
});

api.post("/customers", (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.phone) return res.status(400).json({ error: "姓名和联系电话为必填项" });
  if (b.contractEnd && !DATE_RE.test(b.contractEnd)) return res.status(400).json({ error: "协议到期日期格式应为 YYYY-MM-DD" });
  const list = readCustomers(req);
  const rec = {
    id: "KH-" + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString("hex").toUpperCase(),
    name: String(b.name).trim(),
    phone: String(b.phone).trim(),
    idAddress: String(b.idAddress || "").trim(),
    installAddress: String(b.installAddress || "").trim(),
    planName: String(b.planName || "").trim(),
    planFee: b.planFee === "" || b.planFee == null ? null : Number(b.planFee),
    addonServices: String(b.addonServices || "").trim(),
    operator: String(b.operator || "").trim(),
    remark: String(b.remark || "").trim(),
    contractStart: DATE_RE.test(b.contractStart || "") ? b.contractStart : "",
    contractEnd: DATE_RE.test(b.contractEnd || "") ? b.contractEnd : "",
    createdAt: new Date().toISOString()
  };
  list.push(rec);
  writeCustomers(req, list);
  res.json({ customer: decorate(rec) });
});

api.put("/customers/:id", (req, res) => {
  const list = readCustomers(req);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "客户不存在" });
  const b = req.body || {};
  if (b.contractEnd !== undefined && !DATE_RE.test(b.contractEnd || "")) {
    return res.status(400).json({ error: "协议到期日期格式应为 YYYY-MM-DD" });
  }
  const upd = Object.assign({}, list[idx]);
  ["name", "phone", "idAddress", "installAddress", "planName", "addonServices", "operator", "remark", "contractStart", "contractEnd"].forEach((k) => {
    if (b[k] !== undefined) upd[k] = String(b[k] == null ? "" : b[k]).trim();
  });
  if (b.planFee !== undefined) upd.planFee = b.planFee === "" || b.planFee == null ? null : Number(b.planFee);
  if (!upd.name || !upd.phone) return res.status(400).json({ error: "姓名和联系电话为必填项" });
  list[idx] = upd;
  writeCustomers(req, list);
  res.json({ customer: decorate(upd) });
});

api.delete("/customers/:id", (req, res) => {
  const list = readCustomers(req);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "客户不存在" });
  const removed = list.splice(idx, 1)[0];
  writeCustomers(req, list);
  res.json({ deleted: removed.id });
});

// 数据导入：multipart 表单，字段 file（文件）、mode（append=追加 / replace=清空后导入）
api.post("/import", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "请上传文件" });
  const mode = String(req.body.mode || "append") === "replace" ? "replace" : "append";
  let type = String((req.body && req.body.type) || "").trim() === "portin" ? "portin" : "customers";
  const filename = String(req.file.originalname || "");
  const ext = path.extname(filename).toLowerCase();

  // 管理员可导入到指定用户（uid 为空则导入到当前用户）
  let targetUid = req.auth ? req.auth.uid : userOf(req);
  const bodyUid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "");
  if (bodyUid) {
    const a = req.auth || {};
    if (!a.isSuper && !isAdminUser(a.uid || userOf(req))) return res.status(403).json({ error: "仅管理员可导入到指定用户" });
    targetUid = bodyUid;
  }

  let rows = []; // 二维数组
  let jsonObjects = null;   // 正式客户 JSON 记录
  let jsonPortin = null;    // 异网用户 JSON 记录

  try {
    if (ext === ".xlsx" || ext === ".xls") {
      const wb = XLSX.read(req.file.buffer, { type: "buffer", cellDates: true });
      const ws = wb.Sheets[wb.SheetNames[0]];
      rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true });
      rows = rows.map((r) => r.map(cellText));
    } else if (ext === ".json") {
      const parsed = JSON.parse(req.file.buffer.toString("utf8"));
      // 兼容本应用「导出数据」生成的 JSON（{exportedAt,type,scope,count,items:[...]}），可直接回导
      if (Array.isArray(parsed)) {
        if (type === "portin") jsonPortin = parsed;
        else jsonObjects = parsed;
      } else if (parsed && Array.isArray(parsed.customers)) {
        jsonObjects = parsed.customers;
      } else if (parsed && Array.isArray(parsed.portin)) {
        jsonPortin = parsed.portin;
      } else if (parsed && Array.isArray(parsed.items)) {
        if (parsed.type === "portin" || type === "portin") jsonPortin = parsed.items;
        else jsonObjects = parsed.items;
      } else {
        return res.status(400).json({ error: "JSON 文件需为数组，或包含 customers / portin / items 数组（可直接回导本应用导出的 JSON）" });
      }
    } else {
      // CSV / TXT 及无扩展名文件：按文本解析（自动识别分隔符）
      const text = req.file.buffer.toString("utf8");
      rows = parseTextTable(text);
      if (!rows.length) return res.status(400).json({ error: "未能识别文件内容（支持 CSV / TXT 分隔符：逗号、Tab、分号、竖线）" });
    }
  } catch (e) {
    return res.status(400).json({ error: "文件解析失败：" + (e.message || String(e)) });
  }

  // 表头识别（rows 模式）：命中「家庭住址 / 更换决策人」且未命中「姓名 / 装机地址」→ 异网用户导入
  if (rows.length && !jsonObjects && !jsonPortin) {
    const hit = rows[0].map((h) => String(h || "").trim());
    const hasPortinHdr = hit.some((h) => ["家庭住址", "更换决策人", "familyaddress", "decider"].includes(normHeader(h)));
    const hasCustomerHdr = hit.some((h) => ["姓名", "装机地址", "name", "installaddress"].includes(normHeader(h)));
    if (hasPortinHdr && !hasCustomerHdr) type = "portin";
  }

  const imported = [];
  const errors = [];
  const warnings = [];
  const MAX_ERR = 20;

  function pushRecord(rec, warns, rowNo) {
    if (!rec) {
      if (errors.length < MAX_ERR) errors.push({ row: rowNo, reason: warns });
      return;
    }
    imported.push(rec);
    if (warns && warns.length) warnings.push({ row: rowNo, reasons: warns });
  }

  // 异网用户行 → 记录（支持中文/英文表头，列顺序不限）
  function rowToPortin(cells, mapping) {
    const b = {};
    (mapping || PORTIN_FIELDS).forEach((f, i) => {
      if (mapping) b[f] = cells[i] == null ? "" : cells[i];
      else if (i < cells.length) b[PORTIN_FIELDS[i]] = cells[i];
    });
    const r = buildPortinRecord(b);
    if (r.error) return { fatal: r.error };
    return { rec: r.rec };
  }

  if (jsonPortin) {
    jsonPortin.forEach((obj, i) => {
      if (!obj || typeof obj !== "object") {
        if (errors.length < MAX_ERR) errors.push({ row: i + 1, reason: "记录格式不正确" });
        return;
      }
      const r = buildPortinRecord(obj);
      pushRecord(r.error ? null : r.rec, r.error || [], i + 1);
    });
  } else if (jsonObjects) {
    jsonObjects.forEach((obj, i) => {
      if (!obj || typeof obj !== "object") {
        if (errors.length < MAX_ERR) errors.push({ row: i + 1, reason: "记录格式不正确" });
        return;
      }
      const raw = {};
      CANONICAL_ORDER.forEach((f) => {
        for (const k of Object.keys(obj)) {
          if (fieldByHeader(k) === f) { raw[f] = obj[k]; break; }
        }
      });
      const r = rowToRecordFromRaw(raw);
      pushRecord(r.rec, r.fatal ? r.fatal : r.warns, i + 1);
    });
  } else {
    // 表头识别：首行命中 ≥2 个已知字段名 → 作为表头建立列映射
    let mapping = null;
    let startIdx = 0;
    if (rows.length > 0) {
      if (type === "portin") {
        const pm = rows[0].map(portinFieldByHeader);
        if (pm.filter(Boolean).length >= 2) { mapping = pm; startIdx = 1; }
      } else {
        const hit = rows[0].map(fieldByHeader).filter(Boolean);
        if (hit.length >= 2) { mapping = rows[0].map(fieldByHeader); startIdx = 1; }
      }
    }
    for (let i = startIdx; i < rows.length; i++) {
      const cells = rows[i];
      if (!cells.some((c) => String(c).trim() !== "")) continue; // 空行跳过
      if (type === "portin") {
        const r = rowToPortin(cells, mapping);
        pushRecord(r.rec, r.fatal || [], i + 1);
      } else {
        const r = rowToRecord(cells, mapping);
        pushRecord(r.rec, r.fatal ? r.fatal : r.warns, i + 1);
      }
    }
  }

  if (!imported.length) {
    return res.status(400).json({ imported: 0, skipped: errors.length, errors, warnings, message: "未导入任何有效记录" });
  }

  if (type === "portin") {
    let list = readPortinByUid(targetUid);
    if (mode === "replace") list = [];
    list = list.concat(imported);
    writePortinByUid(targetUid, list);
  } else {
    let list = readCustomersByUid(targetUid);
    if (mode === "replace") list = [];
    list = list.concat(imported);
    writeCustomersByUid(targetUid, list);
  }

  res.json({
    mode,
    type,
    imported: imported.length,
    skipped: errors.length,
    totalRows: errors.length + imported.length,
    errors,
    warnings
  });
});

// ---------------- 异网用户（策反名单）API ----------------
// 字段：联系电话、家庭住址、套餐费用、套餐名称、更换决策人

function portinFilter(list, kw) {
  const k = String(kw || "").trim().toLowerCase();
  if (!k) return list;
  return list.filter((c) =>
    [c.phone, c.familyAddress, c.planName, c.decider, c.operator, c.remark]
      .some((v) => String(v || "").toLowerCase().includes(k))
  );
}

function portinStatsOf(list) {
  const count = list.length;
  const feeSum = list.reduce((s, c) => (c.planFee == null ? s : s + c.planFee), 0);
  return {
    total: count,
    feeSum: Math.round(feeSum * 100) / 100,
    hasDecider: list.filter((c) => String(c.decider || "").trim() !== "").length
  };
}

// 异网用户字段与表头别名（导入用）
const PORTIN_FIELDS = ["phone", "familyAddress", "planName", "planFee", "decider", "operator", "remark"];
const PORTIN_ALIASES = {
  phone: ["联系电话", "电话", "手机", "手机号码", "phone", "tel"],
  familyAddress: ["家庭住址", "住址", "地址", "familyaddress", "homeaddress"],
  planName: ["套餐名称", "套餐", "planname"],
  planFee: ["套餐费用", "套餐费", "月费", "资费", "planfee"],
  decider: ["更换决策人", "决策人", "decider"],
  operator: ["运营商", "所属运营商", "异网运营商", "现用运营商", "operator"],
  remark: ["备注", "备注信息", "备注说明", "remark", "note"]
};
function portinFieldByHeader(h) {
  const key = normHeader(h);
  for (const field of PORTIN_FIELDS) {
    if (PORTIN_ALIASES[field].some((a) => normHeader(a) === key)) return field;
  }
  return null;
}

function buildPortinRecord(b) {
  const phone = String(b.phone || "").trim();
  if (!phone) return { error: "联系电话为必填项" };
  return {
    rec: {
      id: "YW-" + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString("hex").toUpperCase(),
      phone,
      familyAddress: String(b.familyAddress || "").trim(),
      planName: String(b.planName || "").trim(),
      planFee: b.planFee === "" || b.planFee == null ? null : Number(b.planFee),
      decider: String(b.decider || "").trim(),
      operator: String(b.operator || "").trim(),
      remark: String(b.remark || "").trim(),
      createdAt: new Date().toISOString()
    }
  };
}

// 普通用户：自己的异网用户
api.get("/portin", (req, res) => {
  const list = portinFilter(readPortin(req), req.query.q);
  res.json({ portin: list, total: list.length });
});

api.get("/portin/stats", (req, res) => {
  res.json(portinStatsOf(readPortin(req)));
});

api.post("/portin", (req, res) => {
  const r = buildPortinRecord(req.body || {});
  if (r.error) return res.status(400).json({ error: r.error });
  const list = readPortin(req);
  list.push(r.rec);
  writePortin(req, list);
  res.json({ portin: r.rec });
});

api.put("/portin/:id", (req, res) => {
  const list = readPortin(req);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "异网用户不存在" });
  const b = req.body || {};
  const upd = Object.assign({}, list[idx]);
  ["phone", "familyAddress", "planName", "decider", "operator", "remark"].forEach((k) => {
    if (b[k] !== undefined) upd[k] = String(b[k] == null ? "" : b[k]).trim();
  });
  if (b.planFee !== undefined) upd.planFee = b.planFee === "" || b.planFee == null ? null : Number(b.planFee);
  if (!upd.phone) return res.status(400).json({ error: "联系电话为必填项" });
  list[idx] = upd;
  writePortin(req, list);
  res.json({ portin: upd });
});

api.delete("/portin/:id", (req, res) => {
  const list = readPortin(req);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "异网用户不存在" });
  const removed = list.splice(idx, 1)[0];
  writePortin(req, list);
  res.json({ deleted: removed.id });
});

// 管理员：跨用户异网用户
api.get("/admin/portin", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const list = portinFilter(readPortinByUid(uid), req.query.q);
  res.json({ portin: list, total: list.length, uid });
});

api.get("/admin/portin/stats", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  res.json(portinStatsOf(readPortinByUid(uid)));
});

api.post("/admin/portin", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const r = buildPortinRecord(req.body || {});
  if (r.error) return res.status(400).json({ error: r.error });
  const list = readPortinByUid(uid);
  list.push(r.rec);
  writePortinByUid(uid, list);
  res.json({ portin: r.rec });
});

api.put("/admin/portin/:id", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.body && req.body.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const list = readPortinByUid(uid);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "异网用户不存在" });
  const b = req.body || {};
  const upd = Object.assign({}, list[idx]);
  ["phone", "familyAddress", "planName", "decider", "operator", "remark"].forEach((k) => {
    if (b[k] !== undefined) upd[k] = String(b[k] == null ? "" : b[k]).trim();
  });
  if (b.planFee !== undefined) upd.planFee = b.planFee === "" || b.planFee == null ? null : Number(b.planFee);
  if (!upd.phone) return res.status(400).json({ error: "联系电话为必填项" });
  list[idx] = upd;
  writePortinByUid(uid, list);
  res.json({ portin: upd });
});

api.delete("/admin/portin/:id", (req, res) => {
  if (!requireAdmin(req, res)) return;
  const uid = String((req.query && req.query.uid) || "").replace(/[^\w.-]/g, "");
  if (!uid) return res.status(400).json({ error: "缺少 uid 参数" });
  const list = readPortinByUid(uid);
  const idx = list.findIndex((c) => c.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: "异网用户不存在" });
  const removed = list.splice(idx, 1)[0];
  writePortinByUid(uid, list);
  res.json({ deleted: removed.id });
});

// ---------------- 数据导出（CSV / Excel / JSON） ----------------
// 参数：format=csv|xlsx|json（默认 csv）、type=customers|portin（默认 customers）
// 范围：uid=指定用户（仅管理员）；all=1 全部用户（仅管理员）；否则导出当前用户
api.get("/export", (req, res) => {
  const format = ["csv", "xlsx", "json"].includes(req.query.format) ? req.query.format : "csv";
  const type = req.query.type === "portin" ? "portin" : "customers";

  let rows;
  let scopeName = "";
  const uid = String(req.query.uid || "").replace(/[^\w.-]/g, "");
  if (uid) {
    const a = req.auth || {};
    if (!a.isSuper && !isAdminUser(a.uid || userOf(req))) return res.status(403).json({ error: "仅管理员可导出指定用户数据" });
    rows = type === "portin" ? readPortinByUid(uid) : readCustomersByUid(uid);
    scopeName = uid + "-";
  } else if (req.query.all === "1") {
    const a = req.auth || {};
    if (!a.isSuper && !isAdminUser(a.uid || userOf(req))) return res.status(403).json({ error: "仅管理员可导出全部用户数据" });
    rows = type === "portin" ? readAllPortin() : readAllCustomers();
    scopeName = "全部用户-";
  } else {
    rows = type === "portin" ? readPortin(req) : readCustomers(req);
  }

  const typeName = type === "portin" ? "异网用户" : "客户资料";
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
  const base = typeName + "-" + scopeName + stamp;

  if (format === "json") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodeURIComponent(base + ".json"));
    return res.send(JSON.stringify({ exportedAt: new Date().toISOString(), type, scope: scopeName || "current", count: rows.length, items: rows }, null, 2));
  }

  if (format === "xlsx") {
    const fields = type === "portin"
      ? [{ c: "联系电话", k: "phone" }, { c: "家庭住址", k: "familyAddress" }, { c: "运营商", k: "operator" }, { c: "套餐费用", k: "planFee" }, { c: "套餐名称", k: "planName" }, { c: "更换决策人", k: "decider" }, { c: "备注", k: "remark" }]
      : [{ c: "姓名", k: "name" }, { c: "联系电话", k: "phone" }, { c: "运营商", k: "operator" }, { c: "身份证住址", k: "idAddress" }, { c: "装机地址", k: "installAddress" }, { c: "套餐名称", k: "planName" }, { c: "套餐费用", k: "planFee" }, { c: "小业务", k: "addonServices" }, { c: "备注", k: "remark" }, { c: "协议开始日期", k: "contractStart" }, { c: "协议到期日期", k: "contractEnd" }, { c: "到期状态", k: "status" }, { c: "剩余天数", k: "daysLeft" }];
    const data = rows.map((r) => {
      const dec = type === "portin" ? r : decorate(r);
      const o = {};
      fields.forEach((f) => { o[f.c] = dec[f.k] == null ? "" : dec[f.k]; });
      return o;
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data), typeName);
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodeURIComponent(base + ".xlsx"));
    return res.send(Buffer.from(buf));
  }

  // CSV（带 BOM，Excel 直接打开中文不乱码）
  const fields = type === "portin"
    ? [{ c: "联系电话", k: "phone" }, { c: "家庭住址", k: "familyAddress" }, { c: "运营商", k: "operator" }, { c: "套餐费用", k: "planFee" }, { c: "套餐名称", k: "planName" }, { c: "更换决策人", k: "decider" }, { c: "备注", k: "remark" }]
    : [{ c: "姓名", k: "name" }, { c: "联系电话", k: "phone" }, { c: "运营商", k: "operator" }, { c: "身份证住址", k: "idAddress" }, { c: "装机地址", k: "installAddress" }, { c: "套餐名称", k: "planName" }, { c: "套餐费用", k: "planFee" }, { c: "小业务", k: "addonServices" }, { c: "备注", k: "remark" }, { c: "协议开始日期", k: "contractStart" }, { c: "协议到期日期", k: "contractEnd" }, { c: "到期状态", k: "status" }, { c: "剩余天数", k: "daysLeft" }];
  const esc = (v) => {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const lines = [fields.map((f) => esc(f.c)).join(",")];
  for (const r of rows) {
    const dec = type === "portin" ? r : decorate(r);
    lines.push(fields.map((f) => esc(dec[f.k])).join(","));
  }
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodeURIComponent(base + ".csv"));
  res.send("\uFEFF" + lines.join("\r\n"));
});

app.use(GATEWAY_PREFIX + "/api", api);

// 静态前端（本地开发时前端构建产物放在 backend/public）
if (fs.existsSync(PUBLIC_DIR)) {
  app.use(GATEWAY_PREFIX, express.static(PUBLIC_DIR));
}

// ---------------- 启动 ----------------
// 统一网关 socket（fnOS 内 /app/custdb 访问）+ TCP 端口（局域网直连 / 隧道映射）
app.listen(PORT, () => {
  console.log(`[custdb] listening on http://0.0.0.0:${PORT}${GATEWAY_PREFIX} (prefix ${GATEWAY_PREFIX}, data ${DATA_DIR})`);
});

if (SOCKET_PATH) {
  const dir = path.dirname(SOCKET_PATH);
  fs.mkdirSync(dir, { recursive: true });
  try { fs.unlinkSync(SOCKET_PATH); } catch (e) { /* 忽略 */ }
  app.listen(SOCKET_PATH, () => {
    console.log(`[custdb] listening on socket ${SOCKET_PATH} (prefix ${GATEWAY_PREFIX}, data ${DATA_DIR})`);
  });
}
